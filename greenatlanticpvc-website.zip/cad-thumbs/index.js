/* Filled in by the GitHub "Copy old CAD files" step: drawing path -> thumbnail. */
window.GA_THUMBS = window.GA_THUMBS || {};
